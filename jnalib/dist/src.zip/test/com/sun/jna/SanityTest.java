package com.sun.jna;

import junit.framework.TestCase;

public class SanityTest extends TestCase {
    public void testSanity() throws Exception {
        final NativeLibrary lib = NativeLibrary.getInstance("python");

        assertEquals("/usr/lib/libpython.dylib", lib.getFile().getPath());

        Function fn = lib.getFunction("Py_Initialize");
        assertNotNull(fn);

        fn = lib.getFunction("Py_InitModule4");
        assertNotNull(fn);
    }

    public static void main(java.lang.String[] argList) {
        junit.textui.TestRunner.run(SanityTest.class);
    }
}