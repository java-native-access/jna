/* Copyright (c) 2007 Timothy Wall, All Rights Reserved
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.  
 */
package com.sun.jna.platform.win32;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.platform.win32.W32API.DWORD;
import com.sun.jna.ptr.ByReference;

/**
 * This module defines the 32-Bit Windows types and constants that are defined
 * by NT, but exposed through the Win32 API.
 * 
 * Ported from WinNT.h.
 * 
 * @author dblock[at]dblock.org Windows SDK 6.0A
 */
public abstract class WinNT {

	//
	// The following are masks for the predefined standard access types
	//

	public static final int DELETE = 0x00010000;
	public static final int READ_CONTROL = 0x00020000;
	public static final int WRITE_DAC = 0x00040000;
	public static final int WRITE_OWNER = 0x00080000;
	public static final int SYNCHRONIZE = 0x00100000;

	public static final int STANDARD_RIGHTS_REQUIRED = 0x000F0000;

	public static final int STANDARD_RIGHTS_READ = READ_CONTROL;
	public static final int STANDARD_RIGHTS_WRITE = READ_CONTROL;
	public static final int STANDARD_RIGHTS_EXECUTE = READ_CONTROL;

	public static final int STANDARD_RIGHTS_ALL = 0x001F0000;

	public static final int SPECIFIC_RIGHTS_ALL = 0x0000FFFF;

	//
	// Token Specific Access Rights.
	//

	/**
	 * Required to attach a primary token to a process. The
	 * SE_ASSIGNPRIMARYTOKEN_NAME privilege is also required to accomplish this
	 * task.
	 */
	public static final int TOKEN_ASSIGN_PRIMARY = 0x0001;
	/**
	 * Required to duplicate an access token.
	 */
	public static final int TOKEN_DUPLICATE = 0x0002;
	/**
	 * Required to attach an impersonation access token to a process.
	 */
	public static final int TOKEN_IMPERSONATE = 0x0004;
	/**
	 * Required to query an access token.
	 */
	public static final int TOKEN_QUERY = 0x0008;
	/**
	 * Required to query the source of an access token.
	 */
	public static final int TOKEN_QUERY_SOURCE = 0x0010;
	/**
	 * Required to enable or disable the privileges in an access token.
	 */
	public static final int TOKEN_ADJUST_PRIVILEGES = 0x0020;
	/**
	 * Required to adjust the attributes of the groups in an access token.
	 */
	public static final int TOKEN_ADJUST_GROUPS = 0x0040;
	/**
	 * Required to change the default owner, primary group, or DACL of an access
	 * token.
	 */
	public static final int TOKEN_ADJUST_DEFAULT = 0x0080;
	/**
	 * Required to adjust the session ID of an access token. The SE_TCB_NAME
	 * privilege is required.
	 */
	public static final int TOKEN_ADJUST_SESSIONID = 0x0100;

	public static final int TOKEN_ALL_ACCESS_P = STANDARD_RIGHTS_REQUIRED
			| TOKEN_ASSIGN_PRIMARY | TOKEN_DUPLICATE | TOKEN_IMPERSONATE
			| TOKEN_QUERY | TOKEN_QUERY_SOURCE | TOKEN_ADJUST_PRIVILEGES
			| TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT;

	/**
	 * Combines all possible access rights for a token.
	 */
	public static final int TOKEN_ALL_ACCESS = TOKEN_ALL_ACCESS_P
			| TOKEN_ADJUST_SESSIONID;

	/**
	 * Combines STANDARD_RIGHTS_READ and TOKEN_QUERY.
	 */
	public static final int TOKEN_READ = STANDARD_RIGHTS_READ | TOKEN_QUERY;

	/**
	 * Combines STANDARD_RIGHTS_WRITE, TOKEN_ADJUST_PRIVILEGES,
	 * TOKEN_ADJUST_GROUPS, and TOKEN_ADJUST_DEFAULT.
	 */
	public static final int TOKEN_WRITE = STANDARD_RIGHTS_WRITE
			| TOKEN_ADJUST_PRIVILEGES | TOKEN_ADJUST_GROUPS
			| TOKEN_ADJUST_DEFAULT;

	/**
	 * Combines STANDARD_RIGHTS_EXECUTE and TOKEN_IMPERSONATE.
	 */
	public static final int TOKEN_EXECUTE = STANDARD_RIGHTS_EXECUTE;

	public static final int THREAD_TERMINATE = 0x0001;
	public static final int THREAD_SUSPEND_RESUME = 0x0002;
	public static final int THREAD_GET_CONTEXT = 0x0008;
	public static final int THREAD_SET_CONTEXT = 0x0010;
	public static final int THREAD_QUERY_INFORMATION = 0x0040;
	public static final int THREAD_SET_INFORMATION = 0x0020;
	public static final int THREAD_SET_THREAD_TOKEN = 0x0080;
	public static final int THREAD_IMPERSONATE = 0x0100;
	public static final int THREAD_DIRECT_IMPERSONATION = 0x0200;
	public static final int THREAD_SET_LIMITED_INFORMATION = 0x0400;
	public static final int THREAD_QUERY_LIMITED_INFORMATION = 0x0800;
	public static final int THREAD_ALL_ACCESS = STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | 0x3FF;
	
	/**
	 * The SECURITY_IMPERSONATION_LEVEL enumeration type contains values that specify security 
	 * impersonation levels. Security impersonation levels govern the degree to which a server 
	 * process can act on behalf of a client process.
	 */
	public abstract class SECURITY_IMPERSONATION_LEVEL {
		/**
		 * The server process cannot obtain identification information about the client,
		 * and it cannot impersonate the client. It is defined with no value given, and 
		 * thus, by ANSI C rules, defaults to a value of zero. 
		 */
		public static final int SecurityAnonymous = 0;
		/**
		 * The server process can obtain information about the client, such as security 
		 * identifiers and privileges, but it cannot impersonate the client. This is useful
		 * for servers that export their own objects, for example, database products that 
		 * export tables and views. Using the retrieved client-security information, the 
		 * server can make access-validation decisions without being able to use other 
		 * services that are using the client's security context. 
		 */
		public static final int SecurityIdentification = 1;
		/**
		 * The server process can impersonate the client's security context on its local system. 
		 * The server cannot impersonate the client on remote systems. 
		 */
		public static final int SecurityImpersonation = 2;
		/**
		 * The server process can impersonate the client's security context on remote systems. 
		 */
		public static final int SecurityDelegation = 3;
	}
	
	/**
	 * The TOKEN_INFORMATION_CLASS enumeration type contains values that specify the type of 
	 * information being assigned to or retrieved from an access token. 
	 */
	public abstract class TOKEN_INFORMATION_CLASS {
		public static final int TokenUser = 1;
	    public static final int  TokenGroups = 2; 
	    public static final int  TokenPrivileges = 3; 
	    public static final int  TokenOwner = 4;
	    public static final int  TokenPrimaryGroup = 5; 
	    public static final int  TokenDefaultDacl = 6;
	    public static final int  TokenSource = 7;
	    public static final int  TokenType = 8;
	    public static final int  TokenImpersonationLevel = 9; 
	    public static final int  TokenStatistics = 10;
	    public static final int  TokenRestrictedSids = 11; 
	    public static final int  TokenSessionId = 12;
	    public static final int  TokenGroupsAndPrivileges = 13; 
	    public static final int  TokenSessionReference = 14;
	    public static final int  TokenSandBoxInert = 15;
	    public static final int  TokenAuditPolicy = 16;
	    public static final int  TokenOrigin = 17;
	    public static final int  TokenElevationType = 18;
	    public static final int  TokenLinkedToken = 19; 
	    public static final int  TokenElevation = 20;
	    public static final int  TokenHasRestrictions = 21;
	    public static final int  TokenAccessInformation = 22;
	    public static final int  TokenVirtualizationAllowed = 23; 
	    public static final int  TokenVirtualizationEnabled = 24; 
	    public static final int  TokenIntegrityLevel = 25;
	    public static final int  TokenUIAccess = 26;
	    public static final int  TokenMandatoryPolicy = 27; 
	    public static final int  TokenLogonSid = 28;
	}
	
	/**
	 * The SID_AND_ATTRIBUTES structure represents a security identifier (SID) and its 
	 * attributes. SIDs are used to uniquely identify users or groups.
	 */
	public static class SID_AND_ATTRIBUTES extends Structure {
		public SID_AND_ATTRIBUTES() {
			super();
		}
		
		public SID_AND_ATTRIBUTES(Pointer memory) {
			useMemory(memory);
			read();
		}
		
		/**
		 * Pointer to a SID structure. 
		 */
		public PSID.ByReference Sid;
		
		/**
		 * Specifies attributes of the SID. This value contains up to 32 one-bit flags.
		 * Its meaning depends on the definition and use of the SID. 
		 */
		public int Attributes;
	}
	
	/**
	 * The TOKEN_OWNER structure contains the default owner 
	 * security identifier (SID) that will be applied to newly created objects.
	 */
	public static class TOKEN_OWNER extends Structure {
		public TOKEN_OWNER() {
			super();
		}

		public TOKEN_OWNER(Pointer memory) {
			super(memory);
			read();
		}

		/**
		 * Pointer to a SID structure representing a user who will become the owner of any 
		 * objects created by a process using this access token. The SID must be one of the 
		 * user or group SIDs already in the token. 
		 */
		public PSID.ByReference Owner; // PSID
	}

	public static class PSID extends Structure {
		
    	public static class ByReference extends PSID implements Structure.ByReference {
    		
    	}
		
		public PSID() {
			super();
		}
		
		public PSID(byte[] data) {
			super();
			Memory memory = new Memory(data.length);
			memory.write(0, data, 0, data.length);
			setPointer(memory);
		}
		
		public PSID(Pointer memory) {
			super(memory);
			read();
		}

        public void setPointer(Pointer p) {
            useMemory(p);
            read();
        }
		
        public byte[] getBytes() {
        	int len = Advapi32.INSTANCE.GetLengthSid(this);
        	return getPointer().getByteArray(0, len);
        }
        
        public Pointer sid;                
	}
	
    public static class PSIDByReference extends ByReference {
        public PSIDByReference() {
            this(null);
        }
        public PSIDByReference(PSID h) {
            super(Pointer.SIZE);
            setValue(h);
        }
        public void setValue(PSID h) {
            getPointer().setPointer(0, h != null ? h.getPointer() : null);
        }
        public PSID getValue() {
            Pointer p = getPointer().getPointer(0);
            if (p == null)
                return null;
            PSID h = new PSID();
            h.setPointer(p);
            return h;
        }
    }
	
	
	/**
	 * The TOKEN_USER structure identifies the user associated with an access token.
	 */
	public static class TOKEN_USER extends Structure {
		public TOKEN_USER() {
			super();
		}
		
		public TOKEN_USER(Pointer memory) {
			super(memory);
			read();
		}

		/**
		 * Specifies a SID_AND_ATTRIBUTES structure representing the user associated with 
		 * the access token. There are currently no attributes defined for user security 
		 * identifiers (SIDs). 
		 */
		public SID_AND_ATTRIBUTES User;
	}
	
	/**
	 * The TOKEN_GROUPS structure contains information about the group security identifiers 
	 * (SIDs) in an access token.
	 */
	public static class TOKEN_GROUPS extends Structure {
		public TOKEN_GROUPS() {
			super();
		}
		
		public TOKEN_GROUPS(Pointer memory) {
			super(memory);
			read();
		}

		/**
		 * Specifies the number of groups in the access token. 
		 */
		public int GroupCount;
		public SID_AND_ATTRIBUTES Group0;
		
		/**
		 * Specifies an array of SID_AND_ATTRIBUTES structures that contain a set of SIDs 
		 * and corresponding attributes. 
		 */
		public SID_AND_ATTRIBUTES[] getGroups() {
			return (SID_AND_ATTRIBUTES[]) Group0.toArray(GroupCount);
		}
	}

	/**
	 * The SID_NAME_USE enumeration type contains values that specify the type of a security identifier (SID).
	 */
	public abstract class SID_NAME_USE { 
		/**
		 * Indicates a user SID. 
		 */
	    public static final int SidTypeUser = 1;
	    /**
	     * Indicates a group SID. 
	     */
	    public static final int SidTypeGroup = 2;
	    /**
	     * Indicates a domain SID. 
	     */
	    public static final int SidTypeDomain = 3;
	    /**
	     * Indicates an alias SID. 
	     */
	    public static final int SidTypeAlias = 4;
	    /**
	     * Indicates a SID for a well-known group. 
	     */
	    public static final int SidTypeWellKnownGroup = 5;
	    /**
	     * Indicates a SID for a deleted account. 
	     */
	    public static final int SidTypeDeletedAccount = 6;
	    /**
	     * Indicates an invalid SID. 
	     */
	    public static final int SidTypeInvalid = 7;
	    /**
	     * Indicates an unknown SID type. 
	     */
	    public static final int SidTypeUnknown = 8;
	    /**
	     * Indicates a SID for a computer. 
	     */
	    public static final int SidTypeComputer = 9;
	    /**
	     * ?
	     */
	    public static final int SidTypeLabel = 10;
	}	
	
    public static final int FILE_LIST_DIRECTORY = 0x00000001;

    public static final int CREATE_NEW =         1;
    public static final int CREATE_ALWAYS =      2;
    public static final int OPEN_EXISTING =      3;
    public static final int OPEN_ALWAYS =        4;
    public static final int TRUNCATE_EXISTING =  5;

    public static final int FILE_FLAG_WRITE_THROUGH =        0x80000000;
    public static final int FILE_FLAG_OVERLAPPED =           0x40000000;
    public static final int FILE_FLAG_NO_BUFFERING =         0x20000000;
    public static final int FILE_FLAG_RANDOM_ACCESS =        0x10000000;
    public static final int FILE_FLAG_SEQUENTIAL_SCAN =      0x08000000;
    public static final int FILE_FLAG_DELETE_ON_CLOSE =      0x04000000;
    public static final int FILE_FLAG_BACKUP_SEMANTICS =     0x02000000;
    public static final int FILE_FLAG_POSIX_SEMANTICS =      0x01000000;
    public static final int FILE_FLAG_OPEN_REPARSE_POINT =   0x00200000;
    public static final int FILE_FLAG_OPEN_NO_RECALL =       0x00100000;

    public static final int GENERIC_WRITE = 0x40000000;
    
    public class SECURITY_ATTRIBUTES extends Structure {
        public final int nLength = size();
        public Pointer lpSecurityDescriptor;
        public boolean bInheritHandle;
    }	
    
    public static final int PAGE_READONLY = 0x02;
    public static final int PAGE_READWRITE = 0x04;
    public static final int PAGE_WRITECOPY = 0x08;
    public static final int PAGE_EXECUTE = 0x10;
    public static final int PAGE_EXECUTE_READ = 0x20;
    public static final int PAGE_EXECUTE_READWRITE = 0x40;    
    
    public static final int SECTION_QUERY = 0x0001;
    public static final int SECTION_MAP_WRITE = 0x0002;
    public static final int SECTION_MAP_READ = 0x0004;
    public static final int SECTION_MAP_EXECUTE = 0x0008;
    public static final int SECTION_EXTEND_SIZE = 0x0010;    
    
	public static final int FILE_SHARE_READ  = 0x00000001;
	public static final int FILE_SHARE_WRITE = 0x00000002; 
	public static final int FILE_SHARE_DELETE = 0x00000004; 
	public static final int FILE_ATTRIBUTE_READONLY = 0x00000001; 
	public static final int FILE_ATTRIBUTE_HIDDEN = 0x00000002; 
	public static final int FILE_ATTRIBUTE_SYSTEM = 0x00000004; 
	public static final int FILE_ATTRIBUTE_DIRECTORY = 0x00000010; 
	public static final int FILE_ATTRIBUTE_ARCHIVE = 0x00000020; 
	public static final int FILE_ATTRIBUTE_DEVICE = 0x00000040; 
	public static final int FILE_ATTRIBUTE_NORMAL = 0x00000080; 
	public static final int FILE_ATTRIBUTE_TEMPORARY = 0x00000100; 
	public static final int FILE_ATTRIBUTE_SPARSE_FILE = 0x00000200; 
	public static final int FILE_ATTRIBUTE_REPARSE_POINT = 0x00000400; 
	public static final int FILE_ATTRIBUTE_COMPRESSED = 0x00000800; 
	public static final int FILE_ATTRIBUTE_OFFLINE = 0x00001000; 
	public static final int FILE_ATTRIBUTE_NOT_CONTENT_INDEXED = 0x00002000; 
	public static final int FILE_ATTRIBUTE_ENCRYPTED = 0x00004000;
	public static final int FILE_ATTRIBUTE_VIRTUAL = 0x00010000;
	public static final int FILE_NOTIFY_CHANGE_FILE_NAME = 0x00000001; 
	public static final int FILE_NOTIFY_CHANGE_DIR_NAME = 0x00000002; 
	public static final int FILE_NOTIFY_CHANGE_NAME = 0x00000003;
	public static final int FILE_NOTIFY_CHANGE_ATTRIBUTES = 0x00000004; 
	public static final int FILE_NOTIFY_CHANGE_SIZE = 0x00000008; 
	public static final int FILE_NOTIFY_CHANGE_LAST_WRITE = 0x00000010; 
	public static final int FILE_NOTIFY_CHANGE_LAST_ACCESS = 0x00000020; 
	public static final int FILE_NOTIFY_CHANGE_CREATION = 0x00000040; 
	public static final int FILE_NOTIFY_CHANGE_SECURITY = 0x00000100; 
	public static final int FILE_ACTION_ADDED  = 0x00000001; 
	public static final int FILE_ACTION_REMOVED  = 0x00000002; 
	public static final int FILE_ACTION_MODIFIED = 0x00000003; 
	public static final int FILE_ACTION_RENAMED_OLD_NAME = 0x00000004; 
	public static final int FILE_ACTION_RENAMED_NEW_NAME = 0x00000005;
	public static final int FILE_CASE_SENSITIVE_SEARCH = 0x00000001; 
	public static final int FILE_CASE_PRESERVED_NAMES = 0x00000002;
	public static final int FILE_UNICODE_ON_DISK = 0x00000004;
	public static final int FILE_PERSISTENT_ACLS = 0x00000008;
	public static final int FILE_FILE_COMPRESSION = 0x00000010; 
	public static final int FILE_VOLUME_QUOTAS = 0x00000020;
	public static final int FILE_SUPPORTS_SPARSE_FILES = 0x00000040; 
	public static final int FILE_SUPPORTS_REPARSE_POINTS = 0x00000080; 
	public static final int FILE_SUPPORTS_REMOTE_STORAGE = 0x00000100; 
	public static final int FILE_VOLUME_IS_COMPRESSED = 0x00008000; 
	public static final int FILE_SUPPORTS_OBJECT_IDS = 0x00010000; 
	public static final int FILE_SUPPORTS_ENCRYPTION = 0x00020000; 
	public static final int FILE_NAMED_STREAMS = 0x00040000; 
	public static final int FILE_READ_ONLY_VOLUME = 0x00080000; 
	public static final int FILE_SEQUENTIAL_WRITE_ONCE = 0x00100000; 
	public static final int FILE_SUPPORTS_TRANSACTIONS = 0x00200000; 
	

    /** 
     * The FILE_NOTIFY_INFORMATION structure describes the changes found by the 
     * ReadDirectoryChangesW function.
     * 
     * This structure is non-trivial since it is a pattern stamped into a large 
     * block of result memory rather than something that stands alone or is used 
     * for input.
     */
	public static class FILE_NOTIFY_INFORMATION extends Structure {
		public int NextEntryOffset;
	    public int Action;
	    public int FileNameLength;
	    // filename is not nul-terminated, so we can't use a String/WString
	    public char[] FileName = new char[1];
	    
	    private FILE_NOTIFY_INFORMATION() { 
	    	
	    }
	    
	    public FILE_NOTIFY_INFORMATION(int size) {
	    	if (size < size()) {
	           throw new IllegalArgumentException("Size must greater than "	
	        		   + size() + ", requested " + size);
	    	}
	    	allocateMemory(size);
	    }
	   
	    /** WARNING: this filename may be either the short or long form of the filename. */
	    public String getFilename() {
	    	return new String(FileName, 0, FileNameLength/2);
	    }
	    
	    public void read() {
	    	// avoid reading filename until we know how long it is
	    	FileName = new char[0];
	    	super.read();
	    	FileName = getPointer().getCharArray(12, FileNameLength/2);
	    }
	    
	    public FILE_NOTIFY_INFORMATION next() {
	    	if (NextEntryOffset == 0)
	    		return null;
	    	FILE_NOTIFY_INFORMATION next = new FILE_NOTIFY_INFORMATION();
	    	next.useMemory(getPointer(), NextEntryOffset);
	    	next.read();
	    	return next;
	    }
	}	
	
	/**
	 * Registry options.
	 */
	
	public static final int KEY_QUERY_VALUE = 0x0001;
	public static final int KEY_SET_VALUE = 0x0002;
	public static final int KEY_CREATE_SUB_KEY = 0x0004;
	public static final int KEY_ENUMERATE_SUB_KEYS = 0x0008;
	public static final int KEY_NOTIFY = 0x0010;
	public static final int KEY_CREATE_LINK = 0x0020;
	public static final int KEY_WOW64_32KEY = 0x0200;
	public static final int KEY_WOW64_64KEY = 0x0100;
	public static final int KEY_WOW64_RES = 0x0300;

	public static final int KEY_READ = STANDARD_RIGHTS_READ |
		KEY_QUERY_VALUE |
		KEY_ENUMERATE_SUB_KEYS |
		KEY_NOTIFY
		& (~SYNCHRONIZE);

	public static final int KEY_WRITE = STANDARD_RIGHTS_WRITE |
	  	KEY_SET_VALUE |
	  	KEY_CREATE_SUB_KEY
	  	& (~SYNCHRONIZE);	

	public static final int KEY_EXECUTE = KEY_READ
	  	& (~SYNCHRONIZE);

	public static final int KEY_ALL_ACCESS = STANDARD_RIGHTS_ALL |
	  	KEY_QUERY_VALUE |
	  	KEY_SET_VALUE |
	  	KEY_CREATE_SUB_KEY |
	  	KEY_ENUMERATE_SUB_KEYS |
	  	KEY_NOTIFY |
	  	KEY_CREATE_LINK
	  	& (~SYNCHRONIZE);

	//
	// Open/Create Options
	//

	/**
	 * Parameter is reserved.
	 */
	public static final int REG_OPTION_RESERVED = 0x00000000;
	/**
	 * Key is preserved when system is rebooted.
	 */
	public static final int REG_OPTION_NON_VOLATILE = 0x00000000; 
	/**
	 * Key is not preserved when system is rebooted.
	 */
	public static final int REG_OPTION_VOLATILE = 0x00000001;
	/**
	 * Created key is a symbolic link.
	 */
	public static final int REG_OPTION_CREATE_LINK = 0x00000002;
	/**
	 * Open for backup or restore special access rules privilege required.
	 */
	public static final int REG_OPTION_BACKUP_RESTORE = 0x00000004;
	/**
	 * Open symbolic link.
	 */
	public static final int REG_OPTION_OPEN_LINK = 0x00000008;

	public static final int REG_LEGAL_OPTION = REG_OPTION_RESERVED |
	 	REG_OPTION_NON_VOLATILE |
	 	REG_OPTION_VOLATILE |
	 	REG_OPTION_CREATE_LINK |
	 	REG_OPTION_BACKUP_RESTORE |
	 	REG_OPTION_OPEN_LINK;

	//
	// Key creation/open disposition
	//

	/**
	 * New Registry Key created.
	 */
	public static final int REG_CREATED_NEW_KEY = 0x00000001;
	/**
	 * Existing Key opened.
	 */
	public static final int REG_OPENED_EXISTING_KEY = 0x00000002;

	public static final int REG_STANDARD_FORMAT = 1;
	public static final int REG_LATEST_FORMAT = 2;
	public static final int REG_NO_COMPRESSION = 4;

	//
	// Key restore & hive load flags
	//

	/**
	 * Restore whole hive volatile.
	 */
	public static final int REG_WHOLE_HIVE_VOLATILE = 0x00000001;
	/**
	 * Unwind changes to last flush.
	 */
	public static final int REG_REFRESH_HIVE = 0x00000002;
	/**
	 * Never lazy flush this hive.
	 */
	public static final int REG_NO_LAZY_FLUSH = 0x00000004;
	/**
	 * Force the restore process even when we have open handles on subkeys.
	 */
	public static final int REG_FORCE_RESTORE = 0x00000008;
	/**
	 * Loads the hive visible to the calling process.
	 */
	public static final int REG_APP_HIVE = 0x00000010;
	/**
	 * Hive cannot be mounted by any other process while in use.
	 */
	public static final int REG_PROCESS_PRIVATE = 0x00000020;
	/**
	 * Starts Hive Journal.
	 */
	public static final int REG_START_JOURNAL = 0x00000040;
	/**
	 * Grow hive file in exact 4k increments.
	 */
	public static final int REG_HIVE_EXACT_FILE_GROWTH = 0x00000080;
	/**
	 * No RM is started for this hive = no transactions.
	 */
	public static final int REG_HIVE_NO_RM = 0x00000100;
	/**
	 * Legacy single logging is used for this hive.
	 */
	public static final int REG_HIVE_SINGLE_LOG = 0x00000200;

	//
	// Unload Flags
	//
	
	public static final int REG_FORCE_UNLOAD = 1;

	//
	// Notify filter values
	//
	
	public static final int REG_NOTIFY_CHANGE_NAME = 0x00000001;
	public static final int REG_NOTIFY_CHANGE_ATTRIBUTES = 0x00000002;
	public static final int REG_NOTIFY_CHANGE_LAST_SET = 0x00000004;
	public static final int REG_NOTIFY_CHANGE_SECURITY = 0x00000008;

	public static final int REG_LEGAL_CHANGE_FILTER = REG_NOTIFY_CHANGE_NAME |
		REG_NOTIFY_CHANGE_ATTRIBUTES |
		REG_NOTIFY_CHANGE_LAST_SET |
		REG_NOTIFY_CHANGE_SECURITY;

	//
	// Predefined Value Types.
	//

	/**
	 * No value type.
	 */
	public static final int REG_NONE = 0 ;
	/**
	 * Unicode null-terminated string.
	 */
	public static final int REG_SZ = 1;
	/**
	 * Unicode null-terminated string with environment variable references.
	 */
	public static final int REG_EXPAND_SZ = 2;
	/**
	 * Free-formed binary.
	 */
	public static final int REG_BINARY = 3;
	/**
	 * 32-bit number.
	 */
	public static final int REG_DWORD = 4;
	/**
	 * 32-bit number, same as REG_DWORD.
	 */
	public static final int REG_DWORD_LITTLE_ENDIAN = 4;
	/**
	 * 32-bit number.
	 */
	public static final int REG_DWORD_BIG_ENDIAN = 5;
	/**
	 * Symbolic link (unicode).
	 */
	public static final int REG_LINK = 6;
	/**
	 * Multiple unicode strings.
	 */
	public static final int REG_MULTI_SZ = 7;
	/**
	 * Resource list in the resource map.
	 */
	public static final int REG_RESOURCE_LIST = 8;
	/**
	 * Resource list in the hardware description.
	 */
	public static final int REG_FULL_RESOURCE_DESCRIPTOR = 9;
	/**
	 * 
	 */
	public static final int REG_RESOURCE_REQUIREMENTS_LIST = 10 ;
	/**
	 * 64-bit number.
	 */
	public static final int REG_QWORD = 11 ;
	/**
	 * 64-bit number, same as REG_QWORD.
	 */
	public static final int REG_QWORD_LITTLE_ENDIAN = 11;

	/**
	 * A 64-bit value that is guaranteed to be unique on the operating system 
	 * that generated it until the system is restarted. 
	 */
	public static class LUID extends Structure {
		int LowPart;
		int HighPart;
	}
	
	/**
	 * A 64-bit integer;
	 * TODO: this should be a union and allow direct 64-bit integer access.
	 */
	public static class LARGE_INTEGER extends Structure {
		public DWORD LowPart;
		public DWORD HighPart;					
	}
}